import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fetch from 'node-fetch';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

// ── CORS ──
const allowedOrigins = [
  'https://logimax.uz',
  'https://www.logimax.uz',
  'http://localhost:3000',
  'http://127.0.0.1:5500',  // Live Server uchun
  process.env.ALLOWED_ORIGIN,
].filter(Boolean);

app.use(cors({
  origin: (origin, cb) => {
    // origin yo'q bo'lsa (curl, Postman) — ruxsat
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error(`CORS: ${origin} ruxsat yo'q`));
  },
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type'],
}));

app.use(express.json({ limit: '2mb' }));

// ── So'rov logi ──
app.use((req, res, next) => {
  const ts = new Date().toISOString();
  console.log(`[${ts}] ${req.method} ${req.path}`);
  next();
});

// ── Health check ──
app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    time: new Date().toISOString(),
    model: 'claude-sonnet-4-20250514',
    apiKey: process.env.ANTHROPIC_API_KEY ? '✅ set' : '❌ missing',
  });
});

// ── SYSTEM PROMPT ──
const DEFAULT_SYSTEM = `You are Logimax AI — an intelligent logistics assistant for the Logimax platform (logimax.uz), a freight delivery service in Uzbekistan.

Your capabilities:
- Calculate estimated freight prices (based on distance, cargo type, weight, tariff)
- Suggest optimal routes between Uzbekistan cities
- Generate logistics documents (Invoice, TTN/waybill, acceptance acts, contracts)
- Generate professional cargo descriptions
- Answer logistics questions and provide support

Key cities and approximate distances from Tashkent:
Samarkand 320km, Bukhara 570km, Namangan 330km, Andijan 350km,
Fergana 370km, Nukus 950km, Termez 650km, Urgench 1000km.

Pricing guidelines (standard tariff):
1000–1500 UZS/km for light cargo, 1500–2500 for standard, 3000–5000 for heavy/special.

Always respond in the SAME language as the user's message (Uzbek, Russian, or English).
Be concise, professional and helpful. Format prices in UZS. Use emojis sparingly.`;

// ── Asosiy AI endpoint ──
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, system } = req.body;

    // Validatsiya
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'messages array kerak (bo\'sh bo\'lmasin)' });
    }

    // Max 20 ta xabar (kontekst limitini saqlash uchun)
    const trimmedMessages = messages.slice(-20);

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      console.error('❌ ANTHROPIC_API_KEY topilmadi!');
      return res.status(500).json({
        error: 'Server sozlanmagan',
        detail: 'ANTHROPIC_API_KEY .env yoki Vercel Environment Variables da yo\'q'
      });
    }

    // Anthropic API ga so'rov
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1024,
        system: system || DEFAULT_SYSTEM,
        messages: trimmedMessages,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error(`❌ Anthropic API xato ${response.status}:`, errText);

      // Foydalanuvchiga tushunarli xato xabari
      const userMsg = response.status === 401
        ? 'API kalit noto\'g\'ri yoki muddati o\'tgan'
        : response.status === 429
          ? 'So\'rov limiti to\'ldi, bir oz kuting'
          : `API xato: ${response.status}`;

      return res.status(response.status).json({ error: userMsg, detail: errText });
    }

    const data = await response.json();
    const text = data.content?.map(b => b.text || '').join('') || '';

    if (!text) {
      return res.status(500).json({ error: 'AI bo\'sh javob qaytardi' });
    }

    res.json({ text });

  } catch (err) {
    console.error('❌ Server xato:', err.message);
    res.status(500).json({
      error: 'Ichki server xatosi',
      detail: err.message
    });
  }
});

// ── 404 handler ──
app.use((_req, res) => {
  res.status(404).json({ error: 'Bunday endpoint yo\'q' });
});

// ── Start ──
app.listen(PORT, () => {
  console.log(`\n✦ Logimax AI Server ishga tushdi`);
  console.log(`   Manzil:  http://localhost:${PORT}`);
  console.log(`   Health:  http://localhost:${PORT}/health`);
  console.log(`   API:     http://localhost:${PORT}/api/chat`);
  console.log(`   API Key: ${process.env.ANTHROPIC_API_KEY ? '✅ topildi' : '❌ topilmadi (.env tekshiring)'}\n`);
});