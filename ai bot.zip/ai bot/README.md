# ✦ Logimax AI Server

Anthropic Claude API uchun backend proxy. `ai.html` sahifasidan keladigan so'rovlarni Anthropic API ga yo'naltiradi.

---

## 📦 Tuzilma

```
logimax-server/
├── server.js        ← Asosiy server
├── package.json
├── .env.example     ← Namuna (nusxa olib .env ga o'zgartiring)
├── .env             ← Sizning API kalitingiz (git ga push qilmang!)
└── .gitignore
```

---

## 🚀 Lokal ishga tushirish

### 1. O'rnatish

```bash
cd logimax-server
npm install
```

### 2. `.env` faylini yaratish

```bash
cp .env.example .env
```

`.env` faylini oching va API kalitingizni kiriting:

```env
ANTHROPIC_API_KEY=sk-ant-api03-xxxxxxxxxxxxxxxxxxxx
PORT=3000
ALLOWED_ORIGIN=*
```

> API kalitni olish: https://console.anthropic.com → API Keys

### 3. Serverni ishga tushirish

```bash
# Oddiy
npm start

# Auto-reload (development)
npm run dev
```

**Natija:**
```
✦ Logimax AI Server running on http://localhost:3000
   Health: http://localhost:3000/health
   API:    http://localhost:3000/api/chat
```

### 4. `ai.html` ni ochish

`ai.html` ni brauzerda oching (oddiy fayl sifatida, yoki local server orqali). Endi AI ishlaydi!

---

## 🌍 Production Deploy

### Variant A — Vercel (eng oson, bepul)

```bash
# Vercel CLI o'rnatish
npm i -g vercel

# Deploy
cd logimax-server
vercel

# Environment variable qo'shish
vercel env add ANTHROPIC_API_KEY
```

`vercel.json` faylini yarating:
```json
{
  "version": 2,
  "builds": [{ "src": "server.js", "use": "@vercel/node" }],
  "routes": [{ "src": "/(.*)", "dest": "server.js" }]
}
```

### Variant B — Railway (bepul tier mavjud)

1. [railway.app](https://railway.app) ga kiring
2. "New Project" → "Deploy from GitHub"
3. Repository ni tanlang
4. Variables bo'limida `ANTHROPIC_API_KEY` qo'shing
5. Deploy tugmachini bosing

### Variant C — VPS (Ubuntu)

```bash
# Server ga kiring
ssh user@your-server-ip

# Node.js o'rnatish (agar yo'q bo'lsa)
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install nodejs -y

# Loyihani ko'chirish
git clone https://github.com/yourname/logimax-server.git
cd logimax-server
npm install

# .env yaratish
echo "ANTHROPIC_API_KEY=sk-ant-..." > .env
echo "PORT=3000" >> .env
echo "ALLOWED_ORIGIN=https://logimax.uz" >> .env

# PM2 bilan doimiy ishlatish
npm install -g pm2
pm2 start server.js --name logimax-ai
pm2 save
pm2 startup
```

**Nginx reverse proxy** (80/443 port uchun):
```nginx
server {
    server_name api.logimax.uz;

    location /api/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 🔗 `ai.html` ni serverga ulash

Deploy qilingandan so'ng `ai.html` dagi `API_URL` ni o'zgartiring.

**1-usul — HTML faylga to'g'ridan qo'shish** (`<script>` dan oldin):
```html
<script>
  window.AI_API_URL = 'https://api.logimax.uz/api/chat';
</script>
```

**2-usul — `ai.html` ichidagi satr** (server.js URL qatorini toping):
```js
// Bu satrni toping va o'zgartiring:
const API_URL = window.AI_API_URL || 'http://localhost:3000/api/chat';
// ↓ Production uchun:
const API_URL = window.AI_API_URL || 'https://api.logimax.uz/api/chat';
```

---

## 🛡️ Xavfsizlik

| Muammo | Yechim |
|--------|--------|
| API kaliti oshkor bo'lishi | `.env` fayliga saqlang, git ignore qiling |
| Haddan ko'p so'rovlar | Rate limiting qo'shing (express-rate-limit) |
| CORS | Production da `ALLOWED_ORIGIN=https://logimax.uz` qiling |
| Xarajat nazorati | Anthropic dashboard da spending limit qo'ying |

### Rate limiting qo'shish (ixtiyoriy)

```bash
npm install express-rate-limit
```

`server.js` ga qo'shing:
```js
import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 60 * 1000,  // 1 daqiqa
  max: 20,               // 1 daqiqada max 20 so'rov
  message: { error: 'Juda ko\'p so\'rov. 1 daqiqadan so\'ng urinib ko\'ring.' }
});

app.use('/api/', limiter);
```

---

## 🧪 Test

```bash
# Health check
curl http://localhost:3000/health

# Chat test
curl -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Toshkentdan Samarqandga 2 tonna yuk narxi?"}]}'
```

---

## 📞 Muammo bo'lsa

- `ANTHROPIC_API_KEY` to'g'ri ekanini tekshiring
- `npm install` qayta bajaring
- Port 3000 band bo'lsa: `PORT=3001 npm start`
- CORS xatoligi: brauzer console da `Access-Control` xatosini ko'ring
