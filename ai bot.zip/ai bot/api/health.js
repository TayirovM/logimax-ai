export default function handler(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({
        status: 'ok',
        time: new Date().toISOString(),
        model: 'claude-sonnet-4-20250514',
        apiKey: process.env.ANTHROPIC_API_KEY ? '✅ set' : '❌ missing',
    });
}