const DEFAULT_SYSTEM = `You are Logimax AI — an intelligent logistics assistant for the Logimax platform (logimax.uz), a freight delivery service in Uzbekistan.

Your capabilities:
- Calculate estimated freight prices (based on distance, cargo type, weight, tariff)
- Suggest optimal routes between Uzbekistan cities
- Generate logistics documents (Invoice, TTN/waybill, acceptance acts, contracts)
- Generate professional cargo descriptions
- Answer logistics questions and provide support

Key cities and approximate distances from Tashkent:
Samarkand 320km, Bukhara 570km, Namangan 330km, Andijan 350km,
Fergana 370km, Nukus 950km, Termez 650km, Urgench 1000km.

Pricing guidelines (standard tariff):
1000-1500 UZS/km for light cargo, 1500-2500 for standard, 3000-5000 for heavy/special.

Always respond in the SAME language as the user's message (Uzbek, Russian, or English).
Be concise, professional and helpful. Format prices in UZS. Use emojis sparingly.`;

export default async function handler(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'POST') return res.status(405).json({ error: 'Faqat POST' });

    try {
        const { messages, system } = req.body;

        if (!messages || !Array.isArray(messages) || messages.length === 0) {
            return res.status(400).json({ error: 'messages array kerak' });
        }

        const apiKey = process.env.ANTHROPIC_API_KEY;
        if (!apiKey) {
            return res.status(500).json({ error: 'ANTHROPIC_API_KEY sozlanmagan' });
        }

        const response = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': apiKey,
                'anthropic-version': '2023-06-01',
            },
            body: JSON.stringify({
                model: 'claude-sonnet-4-20250514',
                max_tokens: 1024,
                system: system || DEFAULT_SYSTEM,
                messages: messages.slice(-20),
            }),
        });

        if (!response.ok) {
            const err = await response.text();
            const msg = response.status === 401 ? "API kalit noto'g'ri"
                : response.status === 429 ? "So'rov limiti to'ldi"
                    : `API xato: ${response.status}`;
            return res.status(response.status).json({ error: msg, detail: err });
        }

        const data = await response.json();
        const text = data.content?.map(b => b.text || '').join('') || '';
        res.json({ text });

    } catch (err) {
        console.error('Handler xato:', err);
        res.status(500).json({ error: 'Ichki xato', detail: err.message });
    }
}